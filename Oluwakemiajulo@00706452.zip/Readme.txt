1. Introduction:
   this Readme file contains instructions on the jupyter notes and notes in Google colab

2. jupyter notes: Anaconda should be installed and jupyter notebook launched.
  		 Run required libraries.
3. Google colab: open google colab with a google account
                 launch the notebook 
                 run the required libraries.
4. Data sources: Wine Quality - Wine Quality - UCI Machine Learning Repository
                 Dynamics of Insatgram users - Dynamics of Instagram Users (zenodo.org)
                 British Airways reviews - British Airways Passenger Reviews (2016 - 2023) (kaggle.com)
               